import yt_dlp
import logging
import os
import re
from datetime import datetime
from typing import Optional, Dict, Any
from pathlib import Path
from dataclasses import dataclass

from config.settings import settings

logger = logging.getLogger(__name__)


@dataclass
class DownloadResult:
    """Result of a download operation"""
    success: bool
    file_path: Optional[str] = None
    title: Optional[str] = None
    artist: Optional[str] = None
    duration: Optional[float] = None
    file_size: Optional[int] = None
    error_message: Optional[str] = None


class MusicDownloader:
    """Enhanced music downloader with better error handling and metadata extraction"""
    
    def __init__(self, output_dir: str = None):
        self.output_dir = Path(output_dir or settings.output_directory)
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Ensure output directory exists
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
    def _sanitize_filename(self, filename: str) -> str:
        """Sanitize filename for filesystem compatibility"""
        # Remove or replace invalid characters
        filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
        # Remove multiple spaces and trim
        filename = re.sub(r'\s+', ' ', filename).strip()
        # Limit length
        if len(filename) > 200:
            filename = filename[:200] + "..."
        return filename
    
    def _extract_metadata(self, info: Dict[str, Any]) -> Dict[str, Any]:
        """Extract relevant metadata from yt-dlp info"""
        return {
            'title': info.get('title', '').strip(),
            'artist': info.get('uploader', '').strip() or info.get('creator', '').strip(),
            'duration': info.get('duration'),  # in seconds
            'description': info.get('description', ''),
            'upload_date': info.get('upload_date'),
            'view_count': info.get('view_count'),
            'webpage_url': info.get('webpage_url'),
        }
    
    def download_audio(self, url: str) -> DownloadResult:
        """
        Download audio from URL and convert to MP3
        
        Args:
            url: URL to download from
            
        Returns:
            DownloadResult with success status and metadata
        """
        try:
            # Create unique subdirectory for this download
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            download_dir = self.output_dir / f"download_{timestamp}"
            download_dir.mkdir(exist_ok=True)
            
            # Configure yt-dlp options
            ydl_opts = {
                'format': 'bestaudio/best',
                'outtmpl': str(download_dir / '%(title)s.%(ext)s'),
                'postprocessors': [{
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'mp3',
                    'preferredquality': '192',
                }],
                'quiet': True,
                'no_warnings': False,
                'noplaylist': True,
                'extractaudio': True,
                'audioformat': 'mp3',
                'embed_subs': False,
                'writesubtitles': False,
                'writeautomaticsub': False,
            }
            
            # Download and extract info
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                # Extract info first
                info = ydl.extract_info(url, download=False)
                if not info:
                    return DownloadResult(
                        success=False,
                        error_message="Could not extract video information"
                    )
                
                # Extract metadata
                metadata = self._extract_metadata(info)
                self.logger.info(f"Downloading: {metadata['title']} by {metadata['artist']}")
                
                # Perform download
                ydl.download([url])
                
                # Find the downloaded MP3 file
                mp3_files = list(download_dir.glob("*.mp3"))
                if not mp3_files:
                    return DownloadResult(
                        success=False,
                        error_message="No MP3 file found after download"
                    )
                
                # Get the first (and should be only) MP3 file
                output_file = mp3_files[0]
                
                # Sanitize filename and move to final location
                sanitized_name = self._sanitize_filename(f"{metadata['title']}.mp3")
                final_path = self.output_dir / sanitized_name
                
                # Handle filename conflicts
                counter = 1
                while final_path.exists():
                    name_part = sanitized_name.rsplit('.', 1)[0]
                    final_path = self.output_dir / f"{name_part}_{counter}.mp3"
                    counter += 1
                
                # Move file to final location
                output_file.rename(final_path)
                
                # Clean up temporary directory
                try:
                    download_dir.rmdir()
                except OSError:
                    # Directory not empty, clean up remaining files
                    for file in download_dir.iterdir():
                        file.unlink()
                    download_dir.rmdir()
                
                # Get file size
                file_size = final_path.stat().st_size if final_path.exists() else None
                
                self.logger.info(f"Successfully downloaded: {final_path}")
                
                return DownloadResult(
                    success=True,
                    file_path=str(final_path),
                    title=metadata['title'],
                    artist=metadata['artist'],
                    duration=metadata['duration'],
                    file_size=file_size
                )
                
        except yt_dlp.DownloadError as e:
            error_msg = f"Download failed: {str(e)}"
            self.logger.error(error_msg)
            return DownloadResult(success=False, error_message=error_msg)
            
        except Exception as e:
            error_msg = f"Unexpected error during download: {str(e)}"
            self.logger.error(error_msg, exc_info=True)
            return DownloadResult(success=False, error_message=error_msg)
    
    def get_video_info(self, url: str) -> Optional[Dict[str, Any]]:
        """
        Get video information without downloading
        
        Args:
            url: URL to get info from
            
        Returns:
            Dictionary with video metadata or None if failed
        """
        try:
            ydl_opts = {
                'quiet': True,
                'no_warnings': True,
            }
            
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                return self._extract_metadata(info) if info else None
                
        except Exception as e:
            self.logger.error(f"Failed to extract video info: {e}")
            return None


# Legacy compatibility - keep the old class name but use new implementation
class yt_downloader(MusicDownloader):
    """Legacy compatibility wrapper"""
    
    def __init__(self, output_dir: str = None):
        super().__init__(output_dir)
        # Legacy attributes for backward compatibility
        self.output_filename = ""
        self.output_musicname = ""
        self.download_status = ""
    
    def download_youtube_as_mp3(self, url: str) -> Optional[str]:
        """Legacy method for backward compatibility"""
        result = self.download_audio(url)
        
        if result.success:
            self.output_filename = result.file_path
            self.output_musicname = result.title or "Unknown"
            self.download_status = "Downloaded successfully ✅"
            return result.file_path
        else:
            self.output_filename = ""
            self.output_musicname = "Download failed"
            self.download_status = f"Download failed: {result.error_message} ❌"
            return None


# For testing
if __name__ == "__main__":
    url = input("Enter video URL: ")
    downloader = MusicDownloader()
    result = downloader.download_audio(url)
    
    if result.success:
        print(f"✅ Downloaded: {result.title}")
        print(f"📁 File: {result.file_path}")
        print(f"👤 Artist: {result.artist}")
        print(f"⏱️ Duration: {result.duration}s")
        print(f"📏 Size: {result.file_size} bytes")
    else:
        print(f"❌ Download failed: {result.error_message}")
    